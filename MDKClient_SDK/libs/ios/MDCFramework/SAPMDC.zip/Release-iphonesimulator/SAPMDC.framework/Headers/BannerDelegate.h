//
//  BannerDelegate.h
//  SAPMDC
//
//  Created by Gadre, Ketaki on 12/08/20.
//  Copyright © 2020 SAP. All rights reserved.
//

#ifndef BannerDelegate_h
#define BannerDelegate_h

@interface BannerDelegate : NSObject

- (void)onActionLabelPress;
- (void)onCompletionActionLabelPress;

@end

#endif /* BannerDelegate_h */
