//
//  NavigationBarBridge.h
//  SAPMDCFramework
//
//  Copyright © 2017. SAP. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NavigationBarBridge : NSObject

+(void)applyFioriStyle;

@end
